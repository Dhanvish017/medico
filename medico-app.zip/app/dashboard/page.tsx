import { MedicineList } from "@/components/medicine-list"

export default function Dashboard() {
  return (
    <main className="min-h-screen p-4">
      <MedicineList />
    </main>
  )
}

