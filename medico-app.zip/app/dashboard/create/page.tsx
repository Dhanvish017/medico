import { CreateMedicine } from "@/components/create-medicine"

export default function CreateNew() {
  return (
    <main className="min-h-screen p-4">
      <CreateMedicine />
    </main>
  )
}

