import { CalendarView } from "@/components/calendar-view"

export default function Calendar() {
  return (
    <main className="min-h-screen p-4">
      <CalendarView />
    </main>
  )
}

