"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"

export function CalendarView() {
  const router = useRouter()
  const days = Array.from({ length: 31 }, (_, i) => i + 1)
  const weekDays = ["M", "T", "W", "T", "F", "S", "S"]

  return (
    <Card className="max-w-md mx-auto bg-white shadow-lg">
      <CardHeader>
        <CardTitle className="text-center">February 2025</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-7 gap-1 mb-2">
          {weekDays.map((day) => (
            <div key={day} className="text-center text-sm font-medium text-muted-foreground">
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {days.map((day) => (
            <Button
              key={day}
              variant="ghost"
              className={`h-10 w-full ${day % 3 === 0 ? "bg-[#8778FF] text-white" : ""}`}
            >
              {day}
            </Button>
          ))}
        </div>
        <div className="mt-4">
          <Button variant="ghost" className="w-full text-[#8778FF]" onClick={() => router.back()}>
            Back
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

