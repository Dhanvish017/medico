"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import Image from "next/image"

export function MedicineList() {
  const router = useRouter()

  return (
    <div className="container mx-auto p-4 max-w-2xl">
      <Card className="bg-white shadow-lg">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/medico-xjl0PbgPwsI48mTDEnH38XUlpTiWul.png"
              alt="Medicine bottles"
              width={80}
              height={80}
              className="rounded-lg"
            />
            <div>
              <CardTitle>List of medicine</CardTitle>
              <p className="text-sm text-muted-foreground">Add or remove your daily medicine</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Input placeholder="Medicine name" />
            <Input placeholder="Dosage" />
            <div className="flex space-x-2">
              <Button
                className="flex-1 bg-[#8778FF] hover:bg-[#978BF8]"
                onClick={() => router.push("/dashboard/create")}
              >
                Create new
              </Button>
              <Button variant="destructive" className="bg-[#FE6060]">
                Delete
              </Button>
            </div>
          </div>
          <div className="flex justify-end">
            <Button variant="ghost" className="text-[#8778FF]" onClick={() => router.push("/dashboard/calendar")}>
              View Calendar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

