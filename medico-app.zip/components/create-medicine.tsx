"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import type React from "react" // Added import for React

export function CreateMedicine() {
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission here
    router.push("/dashboard")
  }

  return (
    <Card className="max-w-md mx-auto bg-white shadow-lg">
      <CardHeader>
        <CardTitle>CREATE NEW</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Input placeholder="Title" />
            <Input placeholder="Description" />
            <Input placeholder="Time to take" />
            <Input placeholder="Days to take" />
            <Button type="submit" className="w-full bg-[#8778FF] hover:bg-[#978BF8]">
              CREATE
            </Button>
          </div>
        </form>
        <Button variant="ghost" className="w-full text-[#8778FF]" onClick={() => router.back()}>
          Back
        </Button>
      </CardContent>
    </Card>
  )
}

